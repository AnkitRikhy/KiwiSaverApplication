package com.Automation;

import net.thucydides.core.annotations.Steps;

import com.Automation.pages.ReusableFunctions;
import com.Automation.steps.KiwiSaver_Steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class KiwiSaver_Definition {
	
	@Steps
	KiwiSaver_Steps kiwiSteps;
	
	String testDataSheetName = "KiwiSaver_Data_Sheet";
	
	@Given("(.*) User launches 'Westpac New Zealand' Application")
	public void launchTheApplication(String testCaseName) throws Exception {
		ReusableFunctions.fetchDataFromSheet(testDataSheetName, testCaseName);
		kiwiSteps.launch_Westpac_Application();
	}
	
	@Then("Verify that the user is navigated to home page")
	public void verifyHomePage() {
		kiwiSteps.verify_User_Navigation_To_Home_Page();
	}
	
	@Then("Hover on '(.*)' link in the header section")
	public void hoverOnElement(String element) {
		kiwiSteps.hover_On_This_Element(element);
	}
	
	@And("Verify the section being shown below KiwiSaver link")
	public void verifyKiwiSaverSection() {
		kiwiSteps.verify_Section_Below_Kiwi_Saver_Section();
	}
	
	@Then("Click on '(.*)' button")
	public void clickOnButton(String button) {
		kiwiSteps.click_On_Button(button);
	}
	
	@And("Verify that user navigates to 'KiwiSaver Retirement Scheme' home screen")
	public void verifyKiwiSaverRetirementSchemeScreen()  {
		kiwiSteps.user_Navigates_to_KiwiSaver_Retirement_Scheme_Screen();
	}
	
	@And("Now Verify that the user has navigated to 'KiwiSaver Retirement Calculator' screen")
	public void verifyKiwiSaverRetirementCalculatorScreen() throws Exception {
		kiwiSteps.user_Navigates_to_KiwiSaver_Retirement_Calculator_Screen();
	}
	
	@Then("Click on information icon for 'Current age' field and verify the message below it")
	public void verifyMessageForCurrentAge() throws Exception {
		kiwiSteps.verify_Message_That_Pops_Out_For_Current_Age_Field();
	}
	
	@Then("Enter the details of an '(.*)' person in the calculator")
	public void enterDetailsInCalculator(String type) throws Exception {
		kiwiSteps.enter_The_Details_For_Person(type);
	}

	@And("Verify your 'KiwiSaver' Balance by clicking the calculator button")
	public void verifyKiwiSaverBalance() throws Exception {
		kiwiSteps.verify_KiwiSaver_Balance_being_shown_on_the_screen();
		kiwiSteps.KiwiSaver_Balance_Is_Being_Shown();
	}
	
}
