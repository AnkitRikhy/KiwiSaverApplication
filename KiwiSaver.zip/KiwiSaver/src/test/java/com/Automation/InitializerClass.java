package com.Automation;

import com.Automation.pages.ReusableFunctions;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class InitializerClass {

	String ScenarioName = "";
	String TestDataIdentifier = "";

	@Before
	public void setUp(Scenario result) throws Exception {
		System.out.println("***SetUp*****");
		ScenarioName=result.getName();		
	}

	@After
	public void endTestCase(Scenario result) throws Exception {
		ReusableFunctions.testData.clear();
	}
}
