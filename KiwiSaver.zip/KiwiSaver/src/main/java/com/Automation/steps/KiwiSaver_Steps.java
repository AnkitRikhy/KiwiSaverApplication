package com.Automation.steps;

import com.Automation.pages.KiwiSaver_Launch_Page;
import com.Automation.pages.KiwiSaver_RetirementCalculator_Page;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class KiwiSaver_Steps extends ScenarioSteps {

	KiwiSaver_Launch_Page launchScreen;
	KiwiSaver_RetirementCalculator_Page calculatorScreen;
	
	@Step
	public void launch_Westpac_Application() {
		launchScreen.open();
		getDriver().manage().window().maximize();
	}
	
	@Step
	public void verify_User_Navigation_To_Home_Page() {
		launchScreen.verifyUserNavigationToHomePage();
	}
	
	@Step
	public void hover_On_This_Element(String element) {
		launchScreen.hoverOnElement(element);
	}

	@Step
	public void verify_Section_Below_Kiwi_Saver_Section() {
		launchScreen.verifyKiwiSaverSection();
	}
	
	@Step
	public void click_On_Button(String button) {
		launchScreen.clickOnButton(button);
	}

	@Step
	public void user_Navigates_to_KiwiSaver_Retirement_Scheme_Screen() {
		launchScreen.verifyNavigationToRetirementSchemeScreen();
	}

	@Step
	public void user_Navigates_to_KiwiSaver_Retirement_Calculator_Screen() throws Exception {
		calculatorScreen.verifyRetirementCalculatorScreen();
	}

	@Step
	public void verify_Message_That_Pops_Out_For_Current_Age_Field() throws Exception {
		calculatorScreen.verifyMessageForCurrentAge();
	}

	@Step
	public void enter_The_Details_For_Person(String type) throws Exception {
		calculatorScreen.enterDetailsInCalculator(type);
	}
	
	@Step
	public void verify_KiwiSaver_Balance_being_shown_on_the_screen() throws Exception {
		calculatorScreen.verifyKiwiSaverBalance();
	}
	
	@Step
	public void KiwiSaver_Balance_Is_Being_Shown() {
		System.out.println("Checking KiwiSaver Balance");
	}
}
