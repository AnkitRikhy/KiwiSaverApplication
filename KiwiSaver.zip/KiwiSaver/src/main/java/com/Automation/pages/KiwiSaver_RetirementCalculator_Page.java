package com.Automation.pages;

import java.util.HashMap;
import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class KiwiSaver_RetirementCalculator_Page extends PageObject{

	public KiwiSaver_RetirementCalculator_Page(WebDriver driver) {
		super(driver);
	}

	public static HashMap< String, String> calcScreen;

	static {
		calcScreen = new HashMap<String, String>();
		calcScreen.put("KiwiCalculator_Header", "//h1[contains(text(),'KiwiSaver Retirement Calculator')]");
		calcScreen.put("KiwiCalculator_CurrentAge_Label","//label[contains(text(),'Current age')]");
		calcScreen.put("KiwiCalculator_CurrentAge_InfoIcon","//div[@help-id='CurrentAge']/button");
		calcScreen.put("KiwiCalculator_CurrentAge_InfoMessage","//div[@help-id='CurrentAge']//p");
		calcScreen.put("KiwiCalculator_CurrentAge_InputBox","//div[label[contains(text(),'64')]]/preceding-sibling::div//input");
		calcScreen.put("KiwiCalculator_EmploymentStatus","//div[@ng-model='ctrl.data.EmploymentStatus']//i");
		calcScreen.put("KiwiCalculator_Salary_InputBox","//div[@model='ctrl.data.AnnualIncome']//input");
		calcScreen.put("KiwiCalculator_PIR","//div[@ng-model='ctrl.data.PIRRate']//i");
		calcScreen.put("KiwiCalculator_RiskProfile_High","//input[@value='high']");
		calcScreen.put("KiwiCalculator_RiskProfile_Medium","//input[@value='medium']");
		calcScreen.put("KiwiCalculator_RiskProfile_Low","//input[@value='low']");
		calcScreen.put("KiwiCalculator_Savings_InputBox","//div[@model='ctrl.data.SavingsGoal']//input");
		calcScreen.put("KiwiCalculator_VolContribution_InputBox","//div[@model='ctrl.data.VoluntaryContributions']//input");
		calcScreen.put("KiwiCalculator_VolContribution_Frequency","//div[@model='ctrl.data.VoluntaryContributions']//i");
		calcScreen.put("KiwiCalculator_RetirementProjection_Button","//button[@ng-click='ctrl.showResultsPanel()']");
		calcScreen.put("KiwiCalculator_ProjectionChart_Header","//span[contains(text(),'At age 65, your KiwiSaver balance is estimated to be:')]");
		calcScreen.put("KiwiCalculator_KiwiSaverBalance_Field","//div[@class='results-heading']/span[2]");
		calcScreen.put("KiwiCalculator_CurrentBalance_InputBox","//div[@model='ctrl.data.KiwiSaverBalance']//input");
	}
	
	public static HashMap< String, String> infoMessages;
	
	static {
		infoMessages = new HashMap<String, String>();
		infoMessages.put("CurrentAge_InfoMessage", "This calculator has an age limit of 64 years old as you need to be under the age of 65 to join KiwiSaver.");
	}

	/**
	 * Verifying the navigation to Retirement Calculator Screen
	 */
	public void verifyRetirementCalculatorScreen() throws Exception {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_Header")));
		navigateToIframe();
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_CurrentAge_Label")));
	}

	/**
	 * Navigate to iframe
	 */
	public void navigateToIframe() throws Exception {
		getDriver().switchTo().frame(getDriver().findElement(By.cssSelector("iframe[frameborder='no']")));
		Thread.sleep(2000);
	}

	/**
	 *  Verifying the Information Message for 'Current age' field
	 */
	public void verifyMessageForCurrentAge() throws Exception {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_CurrentAge_InfoIcon")));
		ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_CurrentAge_InfoIcon"));
		Thread.sleep(2000);
		//Fetching information message from screen
		String messageFromApp = getDriver().findElement(By.xpath(calcScreen.get("KiwiCalculator_CurrentAge_InfoMessage"))).getText().trim();
		//Comparing both the messages
		if(messageFromApp.equalsIgnoreCase(infoMessages.get("CurrentAge_InfoMessage"))) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		
	}

	/**
	 *  Enter the details in the Calculator section
	 */
	public void enterDetailsInCalculator(String type) throws Exception {
		//Fill Data in Current Age field
		ReusableFunctions.enterData(getDriver(), calcScreen.get("KiwiCalculator_CurrentAge_InputBox"), ReusableFunctions.testData.get("Current_Age"));
		
		// Selecting type of Employment
		ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_EmploymentStatus"));
		ReusableFunctions.click(getDriver(), "//div[@ng-show='dropDownRevealed']//li//span[contains(text(),'" + type + "')]");
		if(type.equalsIgnoreCase("Employed")) {
			ReusableFunctions.enterData(getDriver(), calcScreen.get("KiwiCalculator_Salary_InputBox"), ReusableFunctions.testData.get("Salary_PerAnnum"));
			ReusableFunctions.click(getDriver(), "//div[@ng-model='ctrl.data.KiwiSaverMemberContribution']//div[@class='control-group']/div[2]//input");
		}
		
		//Selecting the type of PIR
		ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_PIR"));
		String PIR = ReusableFunctions.testData.get("PIR");
		ReusableFunctions.click(getDriver(), "//div[@ng-show='dropDownRevealed']//li//span[contains(text(),'" + PIR + "')]");
		
		//Fill Data in Current Balance
		ReusableFunctions.enterData(getDriver(), calcScreen.get("KiwiCalculator_CurrentBalance_InputBox"), ReusableFunctions.testData.get("Current_Balance"));
		
		//Fill Data in Voluntary contributions field
		ReusableFunctions.enterData(getDriver(), calcScreen.get("KiwiCalculator_VolContribution_InputBox"), ReusableFunctions.testData.get("Voluntary_Contribution"));
		
		//Selecting the type of Voluntary Frequency
		String valuationFrequency = ReusableFunctions.testData.get("Voluntary_Contribution_Frequency");
		if(valuationFrequency.length() > 1) {
			ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_VolContribution_Frequency"));
			ReusableFunctions.click(getDriver(), "//div[@ng-show='dropDownRevealed']//li//span[contains(text(),'" + valuationFrequency + "')]");	
		}
		
		//Clicking on Risk Profile type
		String riskProfileType = ReusableFunctions.testData.get("Risk_Profile");
		if(riskProfileType.equalsIgnoreCase("High")) {
			ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_RiskProfile_High"));
		} else if(riskProfileType.equalsIgnoreCase("Medium")) {
			ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_RiskProfile_Medium"));
		} else if(riskProfileType.equalsIgnoreCase("Low")) {
			ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_RiskProfile_Low"));
		}
		
		//Fill Data in Savings field
		ReusableFunctions.enterData(getDriver(), calcScreen.get("KiwiCalculator_Savings_InputBox"), ReusableFunctions.testData.get("Savings_Goal"));
		
	}

	/**
	 *  Verifying the KiwiSaver Balance
	 */
	public void verifyKiwiSaverBalance() throws Exception {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_RetirementProjection_Button")));
		ReusableFunctions.click(getDriver(), calcScreen.get("KiwiCalculator_RetirementProjection_Button"));
		
		//Verifying Kiwi Saver Balance
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_ProjectionChart_Header")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), calcScreen.get("KiwiCalculator_KiwiSaverBalance_Field")));
		
		//Fetching balance from screen
		String kiwiSaverBalance = (getDriver().findElement(By.xpath(calcScreen.get("KiwiCalculator_KiwiSaverBalance_Field"))).getText()).replace(",", "");
		String balanceFromSheet = ReusableFunctions.testData.get("KiwiSaver_Balance");
		//Comparing with balance from sheet
		if(kiwiSaverBalance.contains(balanceFromSheet)) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
	}
}
