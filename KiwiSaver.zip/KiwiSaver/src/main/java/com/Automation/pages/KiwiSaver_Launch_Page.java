package com.Automation.pages;

import java.util.HashMap;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import net.serenitybdd.core.pages.PageObject;

public class KiwiSaver_Launch_Page extends PageObject{
	
	public KiwiSaver_Launch_Page(WebDriver driver) {
		super(driver);
	}

	public static HashMap< String, String> launchScreen;
	
	static {
		launchScreen = new HashMap<String, String>();
		
		//Westpac home screen
		launchScreen.put("HeaderLabel_Personal_link", "//ul[@class='sw-header-menu']//a[contains(text(),'Personal')]");
		launchScreen.put("HeaderLabel_Business_link", "//ul[@class='sw-header-menu']//a[contains(text(),'Business')]");
		launchScreen.put("HeaderLabel_Agribusiness_link", "//ul[@class='sw-header-menu']//a[contains(text(),'Agribusiness')]");
		launchScreen.put("HeaderLabel_Institutional_link", "//ul[@class='sw-header-menu']//a[contains(text(),'Institutional')]");
		launchScreen.put("HeaderLabel_WhoWeAre_link", "//ul[@class='sw-header-menu']//a[contains(text(),'Who We Are')]");
		launchScreen.put("HeaderLabel_REDnews_link", "//ul[@class='sw-header-menu']//a[contains(text(),'REDnews')]");
		launchScreen.put("HeaderLabel_KiwiSaver_link", "//a[@href='/kiwisaver/'][contains(text(),'KiwiSaver')]");
		launchScreen.put("KiwiSaver_AboutKiwiSaver_link", "//a[@href='/kiwisaver/about-kiwisaver/']");
		launchScreen.put("KiwiSaver_HowKiwiSaverWorks_link", "//a[@href='/kiwisaver/about-kiwisaver/how-it-works/']");
		launchScreen.put("KiwiSaver_KiwiSaverBenefits_link", "//a[@href='/kiwisaver/about-kiwisaver/benefits/']");
		launchScreen.put("KiwiSaver_MyKiwiSaver_link", "//a[@href='/kiwisaver/manage-kiwisaver/']");
		launchScreen.put("KiwiSaver_Contributions_link", "//a[@href='/kiwisaver/about-kiwisaver/contributions/']");
		launchScreen.put("KiwiSaver_KiwiSaversCalculators_link", "//a[@href='/kiwisaver/calculators/'][contains(text(),'calculators')]");
		
		//KiwiSaver Retirement Scheme Page
		launchScreen.put("KiwiScheme_Header", "//h1[contains(text(),'Westpac KiwiSaver Scheme Risk Profiler and Retirement Calculator')]");
		launchScreen.put("KiwiScheme_ClickHere_button", "//a[@href='/kiwisaver/calculators/kiwisaver-calculator/'][contains(text(),'started')]");
	}
	
	/**
	 * Verifying the header elements on the home screen
	 */
	public void verifyUserNavigationToHomePage() {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_Personal_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_Business_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_Agribusiness_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_Institutional_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_WhoWeAre_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_REDnews_link")));
	}
	
	/**
	 * Hover on specified elements
	 */
	public void hoverOnElement(String element) {
		switch (element) {
		case "KiwiSaver":
			Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("HeaderLabel_KiwiSaver_link")));
			try {
				ReusableFunctions.HoverOver(launchScreen.get("HeaderLabel_KiwiSaver_link"), getDriver());
				Thread.sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
			break;

		default:
			System.out.println("Element not available in switch");
			Assert.assertTrue(false);
			break;
		}
	}
	
	/**
	 * Verifying the elements below Kiwi Saver link
	 */
	public void verifyKiwiSaverSection() {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_AboutKiwiSaver_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_HowKiwiSaverWorks_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_KiwiSaverBenefits_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_MyKiwiSaver_link")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_Contributions_link")));
	}
	
	/**
	 * Click on specific button
	 */
	public void clickOnButton(String button)  {
		switch (button) {
		case "KiwiSaver calculators":
			Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiSaver_KiwiSaversCalculators_link")));
			try {
				ReusableFunctions.click(getDriver(), launchScreen.get("KiwiSaver_KiwiSaversCalculators_link"));
			} catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
			break;
			
		case "Click here to get started":
			Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiScheme_ClickHere_button")));
			try {
				ReusableFunctions.click(getDriver(), launchScreen.get("KiwiScheme_ClickHere_button"));
			} catch (Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false);
			}
			break;

		default:
			System.out.println("Element not available in switch");
			Assert.assertTrue(false);
			break;
		}
	}

	/**
	 * Verifying the navigation to Retirement Scheme Screen
	 */
	public void verifyNavigationToRetirementSchemeScreen() {
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiScheme_Header")));
		Assert.assertTrue(ReusableFunctions.Displayed(getDriver(), launchScreen.get("KiwiScheme_ClickHere_button")));
	}

}
