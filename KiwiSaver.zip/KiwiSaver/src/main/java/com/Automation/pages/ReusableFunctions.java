package com.Automation.pages;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class ReusableFunctions {

	public static int TimeOut = 10;

	public static HashMap<String, String> testData = new HashMap<String, String>();

	/**
	 *  Method to fetch data from Excel Sheet
	 */
	public static HashMap<String, String> fetchDataFromSheet(String sheetName,String rowKeyword) throws Exception {
		FileInputStream File = new FileInputStream(new File("TestData/TestData.xls"));
		HSSFWorkbook workbook = new HSSFWorkbook(File);
		// Get first sheet from the workbook
		HSSFSheet sheet = workbook.getSheet(sheetName);
		// Get row and column count
		int rowCount = sheet.getPhysicalNumberOfRows();
		int columnCount = sheet.getRow(0).getPhysicalNumberOfCells();
		// Form Hashmap with column name and value.
		for (int i = 0; i < rowCount; i++) {
			System.out.println(i);
			if (sheet.getRow(i).getCell(0).toString().equals(rowKeyword)) {
				for (int k = 0; k < columnCount; k++) {
					testData.put(sheet.getRow(0).getCell(k).toString(), sheet.getRow(i).getCell(k).getStringCellValue());
				}
				break;
			}
		}
		workbook.close();
		File.close();
		return testData;
	}

	/**
	 *  Method to resolve the Selenium dependencies
	 */
	public static By resolveBySelenium(String Locator) {
		By webElementBy = null;

		if (Locator.startsWith("ID:")) {
			String[] Value1 = Locator.split(":", 2);
			String ModifiedXpath = Value1[1];
			webElementBy = By.id(ModifiedXpath);
			System.out.println("Message -->> Found By ID");
		}
		if (Locator.startsWith("Name:")) {
			String[] Array = Locator.split(":", 2);
			webElementBy = By.name(Array[1]);
		} else
			webElementBy = By.xpath(Locator);

		return webElementBy;
	}

	/**
	 *  Verify if an element is displayed and in enabled mode 
	 */
	public static boolean Displayed(WebDriver Driver, String Xpath) {
		boolean found = false;

		try {
			By newWebElementBy = resolveBySelenium(Xpath);

			if (Driver.findElement(newWebElementBy).isDisplayed()&& Driver.findElement(newWebElementBy).isEnabled())
				found = true;

		} catch (Exception E) {
			System.out.println("Message -->> Error:" + E.getMessage());
		}
		return found;
	}

	/**
	 *  Click on element
	 */
	public static void click(WebDriver Driver, String Xpath) throws Exception {
		By newWebElementBy = resolveBySelenium(Xpath);
		Driver.findElement(newWebElementBy).click();
	}

	/**
	 *  Enter data in text box
	 */
	public static void enterData(WebDriver Driver, String Xpath, String Text) throws Exception {
		boolean available = Displayed(Driver,Xpath);
		if(available) {
			By newWebElementBy = resolveBySelenium(Xpath);
			Driver.findElement(newWebElementBy).clear();
			Driver.findElement(newWebElementBy).sendKeys(Text);
			Driver.findElement(newWebElementBy).sendKeys(Keys.TAB);
		}
	}

	/**
	 *  Hover over on an element
	 */
	public static void HoverOver(String path, WebDriver Driver) throws Exception {
		By byLocator = By.xpath(path);
		WebElement elem = Driver.findElement(byLocator);
		Actions action = new Actions(Driver);
		action.moveToElement(elem);
		action.perform();
		Thread.sleep(5000);
	}
}
